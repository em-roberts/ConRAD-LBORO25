import flet as ft

import physics
from crtl_other import ctrl_activity_det, ctrl_activity_src, ctrl_distance
from ctrl_isotope import ctrl_isotope_selection_and_info
from ctrl_material import ctrl_material_selection_and_info
from inp_unit import InputUnit
from out_res import Output, OutputNumberUnit


def main(page: ft.Page) -> None:
    page.title = "ConRAD Lboro"
    page.theme = ft.Theme(color_scheme_seed=ft.Colors.PURPLE)

    page.vertical_alignment = ft.MainAxisAlignment.CENTER
    page.horizontal_alignment = ft.CrossAxisAlignment.CENTER

    def compute(_):
        ctrls = [iso_dd, mat_dd, act_inp, cps_inp, dist_inp]
        if any(not ctrl.valid for ctrl in ctrls):
            for ctrl in doses_out:
                ctrl.set_value(None)
                ctrl.update()
            return

        iso = iso_dd.unit
        mat = mat_dd.unit
        act_raw, act_unit = act_inp.value
        act = act_raw * act_unit
        cps_raw, cps_unit = cps_inp.value
        cps = cps_raw * cps_unit
        dist_raw, dist_unit = dist_inp.value
        dist = dist_raw * dist_unit

        dosages = physics.dosage(iso, mat, act, cps, dist)
        for ctrl, dose in zip(doses_out, dosages):
            ctrl.set_value(dose)
            ctrl.update()

        return

    iso_section, iso_dd = ctrl_isotope_selection_and_info(page, on_change=compute)
    mat_section, mat_dd = ctrl_material_selection_and_info(page, on_change=compute)
    act_section, act_inp = ctrl_activity_src(page, on_change=compute)
    cps_section, cps_inp = ctrl_activity_det(page, on_change=compute)
    dist_section, dist_inp = ctrl_distance(page, on_change=compute)

    doses_out = [
        OutputNumberUnit[float, float](
            Output(label=f"Dosage {symb}"),
            InputUnit(
                value="μSv/hr",
                units={"μSv/hr": 1, "mSv/hr": 1e-3, "Sv/hr": 1e-6},
                label="Unit",
            ),
            combine=lambda v, u: str(v * u),
            alignment=ft.MainAxisAlignment.CENTER,
        )
        for symb in ["α", "β", "ɣ"]
    ]

    URL = "manual.pdf"
    manual = ft.TextButton(
        "Manual",
        icon=ft.icons.HELP,
        tooltip="Open the manual",
        on_click=lambda _: page.launch_url(URL),
    )

    page.add(
        ft.SafeArea(
            ft.Column(
                [
                    ft.Text("Converting Counts to Dose", style=ft.TextStyle(50)),
                    ft.Column(
                        [
                            iso_section,
                            mat_section,
                            act_section,
                            cps_section,
                            dist_section,
                        ],
                        spacing=25,
                        alignment=ft.MainAxisAlignment.START,
                        horizontal_alignment=ft.CrossAxisAlignment.CENTER,
                        width=400,
                    ),
                    ft.Column(
                        [
                            ft.Text(
                                "Output Dosages                                          ",
                                style=ft.TextStyle(20),
                            ),
                            *doses_out,
                            manual,
                        ],
                        alignment=ft.MainAxisAlignment.END,
                        horizontal_alignment=ft.CrossAxisAlignment.CENTER,
                    ),
                ],
                alignment=ft.MainAxisAlignment.SPACE_AROUND,
                horizontal_alignment=ft.CrossAxisAlignment.CENTER,
                expand=True,
                scroll=ft.ScrollMode.ADAPTIVE,
            ),
            expand=True,
        )
    )
