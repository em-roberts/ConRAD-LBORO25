from collections.abc import Callable

import flet as ft
import flet.core.types as ftt

from inp_valid import InputValid, IsValid


class InputNumber(InputValid):
    def __init__(
        self,
        *args,
        is_valid: IsValid | None = None,
        accept_negative: bool = False,
        accept_complex: bool = False,
        **kwargs,
    ) -> None:
        super().__init__(*args, is_valid=self._is_valid, **kwargs)
        self._is_valid_cb = is_valid
        self.accept_negative = accept_negative
        self.accept_complex = accept_complex

    def _is_valid(self, _) -> bool:
        try:
            _ = self.number
            self.error_text = ""
            if len(self.value) <= 0:
                return False
            if not self.accept_negative and self.number < 0:
                self.error_text = "Negative numbers are not allowed"
                return False
            if not self.accept_complex and isinstance(self.number, complex):
                self.error_text = "Complex numbers are not allowed"
                return False
            return self._is_valid_cb is None or self._is_valid_cb(self)
        except ValueError:
            self.error_text = "Invalid number"
            return False
        finally:
            self.update()

    @property
    def number(self) -> float | None:
        if len(self.value) == 0:
            return None
        return float(self.value)


def _from_key(key: str, _value) -> ft.dropdown.Option:
    return ft.dropdown.Option(key)


class InputUnit[T](ft.Dropdown):
    def __init__(
        self,
        *args,
        units: dict[str, T],
        unit_option: Callable[[str, T], ft.dropdown.Option] = _from_key,
        **kwargs,
    ):
        super().__init__(
            *args, options=[unit_option(*u) for u in units.items()], **kwargs
        )
        self._into_option = unit_option
        self.units = units

    @property
    def unit(self) -> T:
        return self.units[self.value]

    def update(self) -> None:
        self.options = [self._into_option(*u) for u in self.units.items()]
        return super().update()

    @property
    def valid(self) -> str:
        return self.value in self.units


class InputUnitNumber[T](ft.Row):
    def __init__(
        self,
        inp_number: InputNumber,
        inp_unit: InputUnit[T],
        *args,
        vertical_alignment: ft.CrossAxisAlignment = ft.CrossAxisAlignment.START,
        **kwargs,
    ) -> None:
        self.inp_number = inp_number
        self.inp_unit = inp_unit
        super().__init__(
            [inp_number, inp_unit],
            *args,
            vertical_alignment=vertical_alignment,
            **kwargs,
        )

    @property
    def valid(self) -> bool:
        return self.inp_number.valid and self.inp_unit.value is not None

    @property
    def value(self) -> tuple[float, T] | None:
        if not self.valid or self.inp_number.number is None:
            return None
        return self.inp_number.number, self.inp_unit.unit


type OnCustomCreate[T] = Callable[[str, T], None]
type OnCustom[T] = Callable[[OnCustomCreate[T]], None]


class InputUnitCustom[T](InputUnit[T]):
    def __init__(
        self,
        *args,
        units: dict[str, T],
        custom: ft.dropdown.Option = ft.dropdown.Option("Custom"),
        on_custom: OnCustom[T],
        on_change: ftt.OptionalControlEventCallable = None,
        **kwargs,
    ):
        self.custom = custom
        self.on_custom = on_custom
        super().__init__(*args, units=units, on_change=self._on_change, **kwargs)
        self.options.insert(0, self.custom)
        self._on_change_cb = on_change

    def update(self) -> None:
        for _ in range(len(self.options) - 1):
            self.options.pop()
        self.options.extend(self._into_option(*u) for u in self.units.items())
        super(ft.Dropdown, self).update()

    def _on_change(self, e: ft.ControlEvent) -> None:
        if e.control.value == self.custom.key:
            return self.on_custom(self._select_custom)
        if self._on_change_cb:
            self._on_change_cb(e)
        return None

    def _select_custom(self, name: str, unit: T) -> None:
        self.units[name] = unit
        self.value = name
        self.update()

        if self._on_change_cb:
            self._on_change_cb(ft.ControlEvent("", "", "", self, None))
