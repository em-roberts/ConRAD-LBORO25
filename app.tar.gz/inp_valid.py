from collections.abc import Callable

import flet as ft
import flet.core.types as ftt

type IsValid = Callable[[InputValid], bool]


class InputValid(ft.TextField):
    def __init__(self, *args, is_valid: IsValid, on_change: ftt.OptionalControlEventCallable = None, **kwargs) -> None:
        super().__init__(*args, on_change=self._on_change, **kwargs)
        self.__is_valid = is_valid
        self._on_change_cb = on_change
        self.valid: bool = False

    def _on_change(self, e: ft.ControlEvent) -> None:
        self.valid = self.__is_valid(self)
        if self._on_change_cb:
            self._on_change_cb(e)
