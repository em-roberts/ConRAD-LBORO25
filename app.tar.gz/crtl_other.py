from collections.abc import Callable

import flet as ft

from inp_unit import InputNumber, InputUnit, InputUnitNumber


def ctrl_activity_src(
    _page: ft.Page,
    on_change: Callable[[InputUnitNumber[float]], None],
) -> tuple[ft.Control, InputUnitNumber[float]]:
    inp = InputUnitNumber(
        InputNumber(
            label="Source Activity",
            hint_text="Activity at the source",
            on_change=on_change,
        ),
        InputUnit(
            value="MBq",
            units={"Bq": 1e-6, "kBq": 1e-3, "MBq": 1, "GBq": 1e3},
            label="Unit",
            on_change=on_change,
        ),
    )

    return inp, inp


def ctrl_activity_det(
    _page: ft.Page,
    on_change: Callable[[InputUnitNumber[float]], None],
) -> tuple[ft.Control, InputUnitNumber[float]]:
    inp = InputUnitNumber(
        InputNumber(
            label="Detector Counts",
            hint_text="Activity at the detctor",
            on_change=on_change,
        ),
        InputUnit(
            value="cps",
            units={"cps": 1e-6},
            label="Unit",
            on_change=on_change,
        ),
    )

    return inp, inp


def ctrl_distance(
    _page: ft.Page,
    on_change: Callable[[InputUnitNumber[float]], None],
) -> tuple[ft.Control, InputUnitNumber[float]]:
    inp = InputUnitNumber(
        InputNumber(
            label="Distance",
            hint_text="Distance of source from detector",
            on_change=on_change,
        ),
        InputUnit(
            value="cm",
            units={"m": 1, "cm": 1e-2, "mm": 1e-3},
            label="Unit",
            on_change=on_change,
        ),
    )

    return inp, inp


def ctrl_surface_area(
    _page: ft.Page,
    on_change: Callable[[InputUnitNumber[float]], None],
) -> tuple[ft.Control, InputUnitNumber[float]]:
    inp = InputUnitNumber(
        InputNumber(
            label="Surface Area",
            hint_text="Surface area of the source",
            on_change=on_change,
        ),
        InputUnit(
            value="mm²",
            units={"m²": 1, "cm²": 1e-4, "mm²": 1e-6},
            label="Unit",
            on_change=on_change,
        ),
    )

    return inp, inp
