import asyncio
import io
import os
from collections.abc import Generator
from contextlib import contextmanager
from pathlib import Path
from typing import Literal, overload

import flet as ft

page: ft.Page

PATH_ASSETS = Path(os.environ.get("FLET_ASSETS_DIR", "assets"))
PATH_STORAGE = Path(os.environ.get("FLET_APP_STORAGE_DATA", "assets"))
KEY_PREFIX = "c2d."


@contextmanager
@overload
def storage(name: str, mode: Literal["r", "w"] = "r") -> Generator[io.StringIO, None, None]: ...


@contextmanager
@overload
def storage(name: str, mode: Literal["rb", "wb"]) -> Generator[io.BytesIO, None, None]: ...


@contextmanager
def storage(name: str, mode: Literal["r", "w", "rb", "wb"] = "r"):
    # If the page is not web, use the file system
    if not page.web:
        file = (PATH_STORAGE / name).open(mode)
        try:
            yield file
        finally:
            file.close()
        return

    # If the page is web, use the client storage
    # This simulates the web local storage as a FileIO
    binary = "b" in mode
    read = "r" in mode
    write = "w" in mode
    key = KEY_PREFIX + name

    buf = _read(key, binary) if read else _new(binary)
    try:
        yield buf
    finally:
        if write:
            _write(key, buf)
        buf.close()


def _read(key: str, binary: bool) -> io.BytesIO | io.StringIO:
    data = page.client_storage.get(key)
    if data is None:
        raise FileNotFoundError(key)
    return io.BytesIO(data) if binary else io.StringIO(data)


def _write(key: str, buf: io.BytesIO | io.StringIO) -> None:
    return page.client_storage.set(key, buf.getvalue())


def _new(binary: bool) -> io.BytesIO | io.StringIO:
    return io.BytesIO() if binary else io.StringIO()
