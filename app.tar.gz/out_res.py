from collections.abc import Callable

import flet as ft

from inp_unit import InputUnit


class Output(ft.TextField):
    def __init__(
        self,
        *args,
        disabled=False,
        filled=True,
        multiline=True,
        border=ft.InputBorder.NONE,
        input_filter=ft.InputFilter(r"^$", replacement_string=""),
        **kwargs,
    ) -> None:
        super().__init__(
            *args,
            disabled=disabled,
            filled=filled,
            multiline=multiline,
            border=border,
            input_filter=input_filter,
            **kwargs,
        )


class OutputNumberUnit[O, T](ft.Row):
    def __init__(
        self,
        output: Output,
        inp_unit: InputUnit[T],
        combine: Callable[[O, T], str],
        *args,
        **kwargs,
    ) -> None:
        self.combine = combine
        self.raw: O | None = None
        self.output = output
        self.inp_unit = inp_unit
        self.inp_unit.on_change = lambda _: self.update()
        super().__init__([output, inp_unit], *args, **kwargs)

    def set_value(self, value: O | None) -> None:
        self.raw = value

    def update(self) -> None:
        if self.raw is None or self.inp_unit.value is None:
            self.output.value = None
            self.output.error_text = ""
            self.inp_unit.error_text = ""
        else:
            try:
                self.output.value = self.combine(self.raw, self.inp_unit.unit)
            except Exception as exc:
                self.output.value = None
                self.output.error_text = str(exc)
                self.inp_unit.error_text = " "
            else:
                self.output.error_text = ""
                self.inp_unit.error_text = ""

        super().update()
