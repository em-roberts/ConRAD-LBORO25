from collections.abc import Callable

import flet as ft

import dataset
from dataset import Material
from inp_unit import (
    InputNumber,
    InputUnit,
    InputUnitCustom,
    InputUnitNumber,
    OnCustomCreate,
)
from inp_valid import InputValid
from out_res import Output, OutputNumberUnit


def ctrl_popup_new(
    page: ft.Page, on_submit: OnCustomCreate[Material]
) -> ft.AlertDialog:
    def can_submit(_):
        btn_submit.disabled = any(not ctrl.valid for ctrl in [inp_name, inp_density])
        page.update()

    def validate_name(ctrl: InputValid):
        name = (ctrl.value or "").strip()
        if name.lower() == "custom":
            ctrl.error_text = "Reserved name"
            return False
        if name in dataset.materials():
            ctrl.error_text = "Material already exists"
            return False
        ctrl.error_text = ""
        return bool(name)

    inp_name = InputValid(
        label="Material Name", is_valid=validate_name, on_change=can_submit
    )
    inp_density = InputUnitNumber(
        InputNumber(label="Density", on_change=can_submit, expand=True),
        InputUnit(
            value="kg/m3",
            units={"kg/m3": 1, "g/cm3": 1000},
            label="Unit",
            on_change=can_submit,
        ),
    )

    def submit(_):
        name = inp_name.value.strip()
        d_raw, d_unit = inp_density.value
        iso: Material = {
            "density": d_raw * d_unit,
        }
        dataset.materials()[name] = iso
        page.close(diag)
        on_submit(name, iso)

    btn_submit = ft.Button(
        "Add",
        icon=ft.Icons.ADD,
        disabled=True,
        on_click=submit,
    )

    diag = ft.AlertDialog(
        title=ft.Text("Add Custom Material", expand=True, width=500),
        content=ft.Column(
            [
                inp_name,
                inp_density,
            ],
            tight=True,
        ),
        actions=[
            ft.Button(
                "Cancel", icon=ft.Icons.CANCEL, on_click=lambda _: page.close(diag)
            ),
            btn_submit,
        ],
    )
    return diag


def ctrl_material_selection_and_info(
    page: ft.Page,
    on_change: Callable[[InputUnitCustom[Material]], None],
) -> tuple[ft.Control, InputUnit[Material]]:
    def select(_) -> None:
        material = dd.unit
        out_density.set_value(material["density"])
        on_change(dd)
        out_density.update()
        page.update()

    def on_custom(create: OnCustomCreate) -> None:
        page.open(ctrl_popup_new(page, on_submit=create))

    dd = InputUnitCustom(
        enable_filter=True,
        on_custom=on_custom,
        on_change=select,
        # Sort the materials by name
        units=dict(sorted(dataset.materials().items(), key=lambda x: x[0])),
        editable=True,
        width=400,
        label="Material",
        tooltip="Select a material",
    )

    out_density = OutputNumberUnit(
        Output(label="Density"),
        InputUnit(
            value="kg/m3",
            units={"kg/m3": 1, "g/cm3": 1000},
            label="Unit",
        ),
        combine=lambda d, u: str(d * u),
    )

    return ft.Column(
        [
            dd,
            ft.Column(
                [
                    out_density,
                ]
            ),
        ],
    ), dd
