import flet as ft


async def main(page: ft.Page) -> None:
    page.adaptive = True
    import fs

    fs.page = page

    import ui

    ui.main(page)


ft.app(main)
