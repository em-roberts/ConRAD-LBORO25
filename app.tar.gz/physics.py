import math

from dataset import Isotope, Material


def dosage(
    isotope: Isotope,
    material: Material,
    activity_src: float,
    activity_det: float,
    distance: float,
) -> float:
    """Calculate the dosage/hr at a given distance from a source.

    Args:
        isotope (Isotope): The isotope used in the calculation.
        material (Material): The material used in the calculation.
        activity_src (float): The activity of the source in MBq.
        detector_det (float): The activity of the detector in MBq.
        distance (float): The distance between the source and the detector in metres.
    Returns:
        float: The dosage in μSv/h."""

    p0 = isotope["weighting_factor"]
    p1 = 144 * activity_det * isotope["energy_initial"] / (math.pi * distance**2)
    p2 = ((1 / distance) * math.log(activity_src / activity_det)) / material["density"]

    return p0 * p1 * p2
