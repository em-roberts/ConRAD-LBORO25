from collections.abc import Callable
import math

from dataset import Isotope, Material


def dosage(
    isotope: Isotope,
    material: Material,
    activity_src: float,
    activity_det: float,
    distance: float,
    surface_area: float,
) -> tuple[float | Exception, float | Exception, float | Exception]:
    """Calculate the dosage/hr at a given distance from a source.

    Args:
        isotope (Isotope): The isotope used in the calculation.
        material (Material): The material used in the calculation.
        activity_src (float): The activity of the source in MBq.
        detector_det (float): The activity of the detector in MBq.
        distance (float): The distance between the source and the detector in metres.
        surface_area (float): The surface area of the source in m**2.
    Returns:
        float: The dosage in μSv/h."""

    alpha = alpha_dosage(
        isotope,
        material,
        activity_det * 1e6,  # Convert to cps from MBq
        distance * 100,  # Convert to cm from m
        surface_area,
    )

    beta = non_alpha_dosage(
        isotope["beta_energy"],
        material,
        activity_src,
        activity_det,
        distance,
    )

    gamma = non_alpha_dosage(
        isotope["gamma_energy"],
        material,
        activity_src,
        activity_det,
        distance,
    )

    return alpha, beta, gamma


def catch_math_or_zero[**P](
    func: Callable[P, float],
) -> Callable[P, float | Exception]:
    """Decorator to catch math errors and return user-friendly string instead of raising an exception."""

    def wrapper(*args: P.args, **kwargs: P.kwargs) -> float | Exception:
        try:
            value = func(*args, **kwargs)
            if value < 0:
                raise ValueError("Negative value encountered in calculation")
            return value
        except ZeroDivisionError:
            return ZeroDivisionError("Division by zero encountered in calculation")
        except Exception as exc:
            return exc

    return wrapper


@catch_math_or_zero
def alpha_dosage(
    isotope: Isotope,
    material: Material,
    activity_det: float,
    distance: float,
    surface_area: float,
) -> float:
    """Calculate the alpha dosage/hr at a given distance from a source.

    Args:
        isotope (Isotope): The isotope used in the calculation.
        material (Material): The material used in the calculation.
        activity_det (float): The activity of the detector in cps.
        distance (float): The distance between the source and the detector in cm.
        surface_area (float): The surface area of the source in m**2.

    Returns:
        float: The alpha dosage in μSv/h.
    """
    energy = (
        isotope["alpha_energy"]
        - 0.9 * distance
        - 0.03 * distance**3
        + 0.2 * math.exp(-0.8 * (distance / 10 - 40) ** 2)
    )

    alpha = (energy * activity_det * 1.15) / (surface_area * material["density"])
    return alpha


@catch_math_or_zero
def non_alpha_dosage(
    energy: float,
    material: Material,
    activity_src: float,
    activity_det: float,
    distance: float,
) -> float:
    """Calculate the beta/gamma dosage/hr at a given distance from a source.

    Args:
        energy (float): The initial energy in MeV.
        material (Material): The material used in the calculation.
        activity_src (float): The activity of the source in MBq.
        activity_det (float): The activity of the detector in MBq.
        distance (float): The distance between the source and the detector in metres.

    Returns:
        float: The dosage in μSv/h.
    """
    p1 = 144 * activity_det * energy / (math.pi * distance**2)
    p2 = ((1 / distance) * math.log(activity_src / activity_det)) / material["density"]
    return p1 * p2
