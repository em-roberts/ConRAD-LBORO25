import math

from dataset import Isotope, Material


def dosage(
    isotope: Isotope,
    material: Material,
    activity_src: float,
    activity_det: float,
    distance: float,
) -> tuple[float, float, float]:
    """Calculate the dosage/hr at a given distance from a source.

    Args:
        isotope (Isotope): The isotope used in the calculation.
        material (Material): The material used in the calculation.
        activity_src (float): The activity of the source in MBq.
        detector_det (float): The activity of the detector in MBq.
        distance (float): The distance between the source and the detector in metres.
    Returns:
        float: The dosage in μSv/h."""

    MAGIC_NUMBER = 5.767e-10
    STOPPING_POWER_APPROX = 1.5
    alpha = (
        (activity_det * (isotope["alpha_energy"] - distance**STOPPING_POWER_APPROX) * MAGIC_NUMBER)
        / (activity_src * material["density"])
        * 1e6  # Convert to μSv/h
    )

    def grace_equation(energy: float):
        p1 = 144 * activity_det * energy / (math.pi * distance**2)
        p2 = ((1 / distance) * math.log(activity_src / activity_det)) / material["density"]
        return p1 * p2

    return (
        alpha if isotope["alpha_energy"] > 0 else 0,
        grace_equation(isotope["beta_energy"]) if isotope["beta_energy"] > 0 else 0,
        grace_equation(isotope["gamma_energy"]) if isotope["gamma_energy"] > 0 else 0,
    )
