import json
import sys
from collections import UserDict
from collections.abc import Callable
from pathlib import Path
from typing import Self, TypedDict

import fs


class FileBackedDict(UserDict):
    def __init__(self, filename: str) -> None:
        self.filename = filename
        with fs.storage(self.filename) as f:
            super().__init__(json.load(f))

    def _save(self) -> None:
        with fs.storage(self.filename, "w") as f:
            json.dump(dict(self), f)

    def __setitem__(self, key, item) -> None:
        super().__setitem__(key, item)
        self._save()

    def __delitem__(self, key) -> None:
        super().__delitem__(key)
        self._save()

    @classmethod
    def from_default(cls, filename: str, default: Path) -> Self:
        try:
            return cls(filename)
        except FileNotFoundError:
            with default.open() as f_src, fs.storage(filename, "w") as f_dst:
                f_dst.write(f_src.read())
            return cls(filename)

    @classmethod
    def from_default_maybe_backup[T](cls, filename: str, default: Path) -> Self | dict[str, T]:
        if sys.platform != "emscripten":
            return cls.from_default(filename, default)
        with default.open() as f:
            return json.load(f)


class Isotope(TypedDict):
    weighting_factor: float
    energy_initial: float  # MeV


class Material(TypedDict):
    density: float  # kg/m^3


__cache = {}


def _cache[T](key: str, new: Callable[[], dict[str, T]]) -> dict[str, T]:
    if (d := __cache.get(key)) is None:
        d = new()
        __cache[key] = d
    return d


def isotopes() -> dict[str, Isotope]:
    return _cache(
        "isotopes",
        lambda: FileBackedDict.from_default_maybe_backup("isotopes.json", fs.PATH_ASSETS / "isotopes_default.json"),
    )


def materials() -> dict[str, Material]:
    return _cache(
        "materials.json",
        lambda: FileBackedDict.from_default_maybe_backup("materials.json", fs.PATH_ASSETS / "materials_default.json"),
    )
