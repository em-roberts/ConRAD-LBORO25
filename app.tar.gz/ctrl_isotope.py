from collections.abc import Callable

import flet as ft

import dataset
from dataset import Isotope
from inp_unit import InputNumber, InputUnit, InputUnitCustom, InputUnitNumber, OnCustomCreate
from inp_valid import InputValid
from out_res import Output, OutputNumberUnit


def ctrl_popup_new(page: ft.Page, on_submit: OnCustomCreate[Isotope]) -> ft.AlertDialog:
    def can_submit(_):
        btn_submit.disabled = any(not ctrl.valid for ctrl in [inp_name, inp_weighting, inp_energy])
        page.update()

    def validate_name(ctrl: InputValid):
        name = (ctrl.value or "").strip()
        if name.lower() == "custom":
            ctrl.error_text = "Reserved name"
            return False
        if name in dataset.isotopes():
            ctrl.error_text = "Isotope already exists"
            return False
        ctrl.error_text = ""
        return bool(name)

    inp_name = InputValid(
        label="Isotope Name", hint_text="Name of the isotope", is_valid=validate_name, on_change=can_submit
    )
    inp_weighting = InputNumber(
        label="Weighting Factor", hint_text="Weighting factor of the isotope", on_change=can_submit
    )
    inp_energy = InputUnitNumber(
        InputNumber(label="Initial Energy", hint_text="TODO", on_change=can_submit, expand=True),
        InputUnit(
            value="MeV",
            units={"MeV": 1, "keV": 1e-3, "eV": 1e-6, "J": 6.242e12},
            label="Unit",
            hint_text="Unit of the weighting factor",
            on_change=can_submit,
        ),
    )

    def submit(_):
        name = inp_name.value.strip()
        e_raw, e_unit = inp_energy.value
        iso: Isotope = {
            "weighting_factor": inp_weighting.number,
            "energy_initial": e_raw * e_unit,
        }
        dataset.isotopes()[name] = iso
        page.close(diag)
        on_submit(name, iso)

    btn_submit = ft.Button(
        "Add",
        icon=ft.Icons.ADD,
        disabled=True,
        on_click=submit,
    )

    diag = ft.AlertDialog(
        title=ft.Text("Add Custom Isotope", width=500),
        content=ft.Column(
            [
                inp_name,
                inp_weighting,
                inp_energy,
            ],
            tight=True,
        ),
        actions=[
            ft.Button("Cancel", icon=ft.Icons.CANCEL, on_click=lambda _: page.close(diag)),
            btn_submit,
        ],
    )
    return diag


def ctrl_isotope_selection_and_info(
    page: ft.Page,
    on_change: Callable[[InputUnitCustom[Isotope]], None],
) -> tuple[ft.Control, InputUnit[Isotope]]:
    def select(_) -> None:
        isotope = dd.unit
        out_wf.value = str(isotope["weighting_factor"])
        out_energy.set_value(isotope["energy_initial"])
        on_change(dd)
        out_energy.update()
        page.update()

    def on_custom(create: OnCustomCreate) -> None:
        page.open(ctrl_popup_new(page, on_submit=create))

    dd = InputUnitCustom(
        enable_filter=True,
        on_custom=on_custom,
        on_change=select,
        # Sort the isotope dd by name
        units=dict(sorted(dataset.isotopes().items(), key=lambda x: x[0])),
        editable=True,
        width=400,
        label="Isotope",
        tooltip="Select an isotope",
    )

    out_wf = Output(label="Weighting Factor")
    out_energy = OutputNumberUnit(
        Output(label="Energy"),
        InputUnit(value="MeV", units={"MeV": 1, "keV": 1e-3, "eV": 1e-6}),
        combine=lambda v, u: str(v * u),
    )

    return ft.Column(
        [
            dd,
            ft.Row(
                [out_wf, out_energy],
                alignment=ft.MainAxisAlignment.SPACE_BETWEEN,
                expand=True,
                wrap=True,
            ),
        ],
        horizontal_alignment=ft.CrossAxisAlignment.CENTER,
    ), dd
