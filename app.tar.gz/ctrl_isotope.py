import operator
from collections.abc import Callable

import flet as ft

import dataset
from dataset import Isotope
from inp_unit import (
    InputNumber,
    InputUnit,
    InputUnitCustom,
    InputUnitNumber,
    OnCustomCreate,
)
from inp_valid import InputValid
from out_res import Output, OutputNumberUnit


def ctrl_popup_new(page: ft.Page, on_submit: OnCustomCreate[Isotope]) -> ft.AlertDialog:
    def can_submit(_):
        btn_submit.disabled = any(not ctrl.valid for ctrl in [inp_name, *inp_energies])
        page.update()

    def validate_name(ctrl: InputValid):
        name = (ctrl.value or "").strip()
        if name.lower() == "custom":
            ctrl.error_text = "Reserved name"
            return False
        if name in dataset.isotopes():
            ctrl.error_text = "Isotope already exists"
            return False
        ctrl.error_text = ""
        return bool(name)

    inp_name = InputValid(
        label="Isotope Name",
        hint_text="Name of the isotope",
        is_valid=validate_name,
        on_change=can_submit,
    )
    inp_energies = [
        InputUnitNumber(
            InputNumber(label=f"Initial {symb} Energy", on_change=can_submit, expand=True),
            InputUnit(
                value="MeV",
                units={"MeV": 1, "keV": 1e-3, "eV": 1e-6, "J": 6.242e12},
                label="Unit",
                hint_text="Unit of the energy",
                on_change=can_submit,
            ),
        )
        for symb in ["α", "β", "ɣ"]
    ]

    def submit(_):
        name = inp_name.value.strip()
        iso: Isotope = Isotope(
            alpha_energy=operator.mul(*inp_energies[0].value),
            beta_energy=operator.mul(*inp_energies[1].value),
            gamma_energy=operator.mul(*inp_energies[2].value),
        )
        dataset.isotopes()[name] = iso
        page.close(diag)
        on_submit(name, iso)

    btn_submit = ft.Button(
        "Add",
        icon=ft.Icons.ADD,
        disabled=True,
        on_click=submit,
    )

    diag = ft.AlertDialog(
        title=ft.Text("Add Custom Isotope", width=500),
        content=ft.Column(
            [
                inp_name,
                *inp_energies,
            ],
            tight=True,
        ),
        actions=[
            ft.Button("Cancel", icon=ft.Icons.CANCEL, on_click=lambda _: page.close(diag)),
            btn_submit,
        ],
    )
    return diag


def ctrl_isotope_selection_and_info(
    page: ft.Page,
    on_change: Callable[[InputUnitCustom[Isotope]], None],
) -> tuple[ft.Control, InputUnit[Isotope]]:
    def select(_) -> None:
        isotope = dd.unit
        out_energies[0].set_value(isotope["alpha_energy"])
        out_energies[1].set_value(isotope["beta_energy"])
        out_energies[2].set_value(isotope["gamma_energy"])
        on_change(dd)
        for ctrl in out_energies:
            ctrl.update()

    def on_custom(create: OnCustomCreate) -> None:
        page.open(ctrl_popup_new(page, on_submit=create))

    dd = InputUnitCustom(
        enable_filter=True,
        on_custom=on_custom,
        on_change=select,
        # Sort the isotope dd by name
        units=dict(sorted(dataset.isotopes().items(), key=lambda x: x[0])),
        editable=True,
        width=400,
        label="Isotope",
        tooltip="Select an isotope",
    )
    out_energies = [
        OutputNumberUnit(
            Output(label=f"Energy {symb}"),
            InputUnit(value="MeV", units={"MeV": 1, "keV": 1e-3, "eV": 1e-6}),
            combine=lambda v, u: str(v * u),
        )
        for symb in ["α", "β", "ɣ"]
    ]

    return ft.Column(
        [
            dd,
            ft.Row(
                out_energies,
                alignment=ft.MainAxisAlignment.SPACE_BETWEEN,
                expand=True,
                wrap=True,
            ),
        ],
        horizontal_alignment=ft.CrossAxisAlignment.CENTER,
    ), dd
